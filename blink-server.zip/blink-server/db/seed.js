// Loads the hand-curated list (freeCodeCamp, Khan Academy, MIT OCW,
// etc.) into the database. Safe to re-run any time — it upserts on
// external_id, so re-seeding just refreshes those rows instead of
// duplicating them.

require("dotenv").config();
const db = require("./index");
const staticCourses = require("../lib/staticCourses");
const domainsData = require("../lib/domainsData");
const { withTransaction } = require("../lib/withTransaction");
const { seedDomains } = require("../lib/seedDomains");

const upsert = db.prepare(`
  INSERT INTO courses (external_id, title, platform, category, level, duration, access, blurb, url, source)
  VALUES (@id, @title, @platform, @category, @level, @duration, @access, @blurb, @url, 'curated')
  ON CONFLICT(external_id) DO UPDATE SET
    title = excluded.title,
    platform = excluded.platform,
    category = excluded.category,
    level = excluded.level,
    duration = excluded.duration,
    access = excluded.access,
    blurb = excluded.blurb,
    url = excluded.url,
    updated_at = CURRENT_TIMESTAMP
`);

const seedAll = withTransaction(db, (items) => {
  items.forEach((item) => upsert.run(item));
});

seedAll(staticCourses);
console.log(`Seeded ${staticCourses.length} curated courses into ${process.env.DB_PATH || "blink.db"}.`);

const { domainCount, skippedCourseIds } = seedDomains(db, domainsData);
console.log(`Seeded ${domainCount} domain roadmaps.`);
if (skippedCourseIds.length > 0) {
  console.warn("Warning: some roadmap steps referenced course IDs that don't exist yet:");
  skippedCourseIds.forEach((line) => console.warn(`  - ${line}`));
}

process.exit(0);
