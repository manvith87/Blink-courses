const express = require("express");
const db = require("../db");

const router = express.Router();

// GET /api/domains — list every domain with a quick step/course count,
// for rendering the "pick a domain" chips.
router.get("/", (req, res) => {
  const domains = db.prepare("SELECT * FROM domains ORDER BY name").all();

  const withCounts = domains.map((domain) => {
    const { stepCount } = db
      .prepare("SELECT COUNT(*) AS stepCount FROM domain_steps WHERE domain_id = ?")
      .get(domain.id);
    const { courseCount } = db
      .prepare(
        `SELECT COUNT(DISTINCT dsc.course_id) AS courseCount
         FROM domain_step_courses dsc
         JOIN domain_steps ds ON ds.id = dsc.step_id
         WHERE ds.domain_id = ?`
      )
      .get(domain.id);
    return { ...domain, stepCount, courseCount };
  });

  res.json(withCounts);
});

// GET /api/domains/:slug — the full roadmap: ordered steps, each with
// its actual course rows attached.
router.get("/:slug", (req, res) => {
  const domain = db.prepare("SELECT * FROM domains WHERE slug = ?").get(req.params.slug);
  if (!domain) return res.status(404).json({ error: "Domain not found" });

  const steps = db
    .prepare("SELECT * FROM domain_steps WHERE domain_id = ? ORDER BY step_order")
    .all(domain.id);

  const stepsWithCourses = steps.map((step) => {
    const courses = db
      .prepare(
        `SELECT c.* FROM domain_step_courses dsc
         JOIN courses c ON c.id = dsc.course_id
         WHERE dsc.step_id = ?
         ORDER BY dsc.position`
      )
      .all(step.id);
    return { ...step, courses };
  });

  res.json({ ...domain, steps: stepsWithCourses });
});

module.exports = router;
